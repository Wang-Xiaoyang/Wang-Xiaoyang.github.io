import gym
import time

env = gym.make('MountainCar-v0')

env.reset()

done = False

while not done:
	env.render()
	#time.sleep(.2)
	
	action = env.action_space.sample() # random action
	obs, reward, done, _ = env.step(action)
	
env.close()
