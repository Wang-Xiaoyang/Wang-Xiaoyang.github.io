%----------------------------------------%
% Build infrared patch model with non-overlap%
%       Date:2015.03                     %
% Revised on 2016.06
% Update on 2021.11: 
%   line 16:   newI=[Up;repmat(Up(m,:),endRow-m,1)];
% modified to: newI=[Up;repmat(Up(p,:),endRow-p,1)];
% This does not affect detection performance.
%----------------------------------------%

function [New,endRow,endColumn]=patch_model(I,m,n)       % m & n shows the number of rows and columns of one patch
I=double(I);
[p q]=size(I);
endRow=ceil(p/m)*m;
endColumn=ceil(q/n)*n;

Up=[I,repmat(I(:,q),1,endColumn-q)];
newI=[Up;repmat(Up(p,:),endRow-p,1)];

T=(endRow*endColumn)/(m*n);      %image patch amount 
N=endColumn/n;          
New=zeros(m*n,T);
for ii=1:T
    t=rem(ii,N);
    if t==0
        t=N;
    end
    New(:,ii)=reshape(newI((ceil(ii/N)-1)*m+1:ceil(ii/N)*m,((t-1)*n+1):t*n),m*n,1);
end
end
